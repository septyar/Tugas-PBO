class Pegawai:
    def __init__(self, id_pegawai, nama, **kwargs):
        super().__init__(**kwargs)
        self.id_pegawai = id_pegawai
        self.nama = nama

class Gaji:
    def __init__(self, gaji, **kwargs):
        super().__init__(**kwargs)
        self.gaji = gaji

class PegawaiProyek:
    def __init__(self, nama_proyek, **kwargs):
        super().__init__(**kwargs)
        self.nama_proyek = nama_proyek

class ProjectManager(Pegawai, Gaji, PegawaiProyek):
    def __init__(self, id_pegawai, nama, gaji, nama_proyek):
        super().__init__(
            id_pegawai=id_pegawai,
            nama=nama,
            gaji=gaji,
            nama_proyek=nama_proyek
        )

    def tampilkan_detail(self):
        print()
        print(f"ID Pegawai  : {self.id_pegawai}")
        print(f"Nama        : {self.nama}")
        print(f"Gaji        : Rp{self.gaji:,.2f}")
        print(f"Nama Proyek : {self.nama_proyek}")

pm = ProjectManager(
    id_pegawai="PM-023",
    nama="Sari Setya Anggraini",
    gaji=7000000,
    nama_proyek="Pengelolaan data Karyawan"
)

pm.tampilkan_detail()
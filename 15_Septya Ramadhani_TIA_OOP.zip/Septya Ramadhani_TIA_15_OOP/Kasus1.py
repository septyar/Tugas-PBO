class Dosen:
    def __init__(self, kode_nidn, nama, kode_prodi, kode_fakultas):
        self.kode_nidn = kode_nidn
        self.nama = nama
        self.kode_prodi = kode_prodi
        self.kode_fakultas = kode_fakultas

    def tampil_profil(self):
        print("PROFIL DOSEN")
        print("NIDN    : ", self.kode_nidn)
        print("Nama    : ", self.nama)
        print("Prodi   : ", self.kode_prodi)
        print("Fakultas: ", self.kode_fakultas)

    def cek_prodi(self):
            if self.kode_prodi == "TI":
                print("Program Studi: Teknik Informatika")
            elif self.kode_prodi == "SI":
                print("Program Studi: Sistem Informasi")
            elif self.kode_prodi == "TIF":
                print("Program Studi: Teknologi Informasi")
            else:
                print("Program Studi Tidak Terdaftar")

dosen1 = Dosen ("1234567", "Anwar Basuri", "TI", "FTI")
dosen2 = Dosen ("7654321", "Rina indrawati", "SI", "FTI")
dosen3 = Dosen ("9876543", "Rohmad Budi", "TIF", "FTI")

dosen1.tampil_profil()
dosen1.cek_prodi()

print()

dosen2.tampil_profil()
dosen2.cek_prodi()

print()

dosen3.tampil_profil()
dosen3.cek_prodi()

print()
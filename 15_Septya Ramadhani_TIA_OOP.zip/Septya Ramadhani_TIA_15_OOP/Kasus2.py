# Class Induk[cite: 2]
class Kendaraan:
    def __init__(self, nama, merk, tahun, kecepatan):
        self.nama = nama
        self.merk = merk
        self.tahun = tahun
        self.kecepatan = kecepatan

    def info_kendaraan(self):
        print(f"Nama      : {self.nama}")
        print(f"Merk      : {self.merk}")
        print(f"Tahun     : {self.tahun}")
        print(f"Kecepatan : {self.kecepatan} km/jam")

class Mobil(Kendaraan):
    def __init__(self, nama, merk, tahun, kecepatan, jumlah_kursi):
        super().__init__(nama, merk, tahun, kecepatan)
        self.jumlah_kursi = jumlah_kursi

    def info_mobil(self):
        self.info_kendaraan()
        print(f"Jml Kursi : {self.jumlah_kursi}")

class Motor(Kendaraan):
    def __init__(self, nama, merk, tahun, kecepatan, tipe_motor):
        super().__init__(nama, merk, tahun, kecepatan)
        self.tipe_motor = tipe_motor

    def info_motor(self):
        self.info_kendaraan()
        print(f"Tipe Motor: {self.tipe_motor}")

car = Mobil("Avanza", "Toyota", 2022, 180, 7)
bike = Motor("NMAX", "Yamaha", 2023, 120, "Matic")

print()
car.info_mobil()

print()
bike.info_motor()
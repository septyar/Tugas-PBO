from datetime import datetime, timedelta

# Waktu lokal saat ini
waktu_lokal = datetime.now()

# Perkiraan waktu berdasarkan selisih jam standar:
# New York biasanya selisih sekitar -11 jam dari waktu Indonesia (WIB)
datetime_NY = waktu_lokal - timedelta(hours=11)
print("NY time:", datetime_NY.strftime("%H:%M:%S"))

# London biasanya selisih sekitar -6 jam dari waktu Indonesia (WIB)
datetime_London = waktu_lokal - timedelta(hours=6)
print("London time:", datetime_London.strftime("%H:%M:%S"))
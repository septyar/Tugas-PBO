import time

time.sleep(2)
print("Wait until 2 seconds.")

# Output: Wait until 2 seconds.
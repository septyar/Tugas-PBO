import time

time_tuple = (2022, 12, 28, 8, 44, 4, 4, 362, 0)

# convert time_tuple to seconds since epoch
seconds = time.mktime(time_tuple)

print(seconds)

# Output: 1672217044.0
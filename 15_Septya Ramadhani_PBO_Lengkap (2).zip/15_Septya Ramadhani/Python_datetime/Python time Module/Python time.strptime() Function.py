import time

time_string = "14 July, 2023"
result = time.strptime(time_string, "%d %B, %Y")

print(result)
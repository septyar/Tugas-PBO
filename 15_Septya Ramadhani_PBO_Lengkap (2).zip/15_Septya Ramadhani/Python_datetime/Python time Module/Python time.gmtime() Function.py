import time

result = time.gmtime(1672214933)
print("result:", result)
print("\nyear:", result.tm_year)
print("tm_hour:", result.tm_hour)
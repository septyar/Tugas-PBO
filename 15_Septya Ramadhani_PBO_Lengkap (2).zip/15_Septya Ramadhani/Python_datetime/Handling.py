from datetime import datetime
from zoneinfo import ZoneInfo

print("Local:", datetime.now().strftime("%m/%d/%Y, %H:%M:%S"))

print("NY:", datetime.now(ZoneInfo('America/New_York')).strftime("%m/%d/%Y, %H:%M:%S"))

print("London:", datetime.now(ZoneInfo('Europe/London')).strftime("%m/%d/%Y, %H:%M:%S"))
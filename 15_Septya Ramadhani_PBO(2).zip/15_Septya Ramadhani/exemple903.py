model = 'ChatGPT'

# Access the last character
print(model[-1])   # Output: T

# Access the fourth last character
print(model[-4])   # Output: t
my_list = [4, 2, 3, [6, 5]]  
print(my_list)

my_tuple = (4, 2, 3, [6,5])
my_tuple[3][0] = 9  
print(my_tuple)

my_tuple = ('p','r','o','g','r','a','m','i','z') 
print(my_tuple)
my_tuple = ('p','r','o','g','r','a','m','i','z')

temp_list = list(my_tuple)
del temp_list[3] 
my_tuple = tuple(temp_list)

print(my_tuple)
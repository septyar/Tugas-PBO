favorite_items = ["T-shirt", "Lamp", "Pen"]

size = len(favorite_items)
print(size)   # 3
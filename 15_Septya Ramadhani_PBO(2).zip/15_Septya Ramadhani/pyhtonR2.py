def recursor():
    print("Fungsi berhasil dipanggil!")

# Panggil fungsi dari luar
recursor()
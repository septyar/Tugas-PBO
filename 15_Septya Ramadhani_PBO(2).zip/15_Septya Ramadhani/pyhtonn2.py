# variabel global
c = 1

def add():
    global c  # Tambahkan baris ini agar variabel c bisa diubah di dalam fungsi
    
    # tambahkan c dengan 2
    c = c + 2
    
    print(c)

add()
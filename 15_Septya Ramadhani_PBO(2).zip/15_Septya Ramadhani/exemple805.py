my_tuple = ('p','r','o','g','r','a','m','i','z')
print(my_tuple[1:4])  # elements 2nd to 4th

print(my_tuple[:-7])  # elements beginning to 2nd

print(my_tuple[7:])   # elements 8th to end

print(my_tuple[:])    # elements beginning to end

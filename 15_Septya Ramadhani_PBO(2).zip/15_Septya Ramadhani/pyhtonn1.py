c = 1 # global variable

def add():
    print(c)

add()

# Output: 1
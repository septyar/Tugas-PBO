model = 'ChatGPT'

# Access the first character
print(model[0])    # Output: C

# Access the fifth character
print(model[4])    # Output: G
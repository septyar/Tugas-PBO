print('Chat' in 'ChatGPT')        # True
print('Claude' not in 'ChatGPT')  # True
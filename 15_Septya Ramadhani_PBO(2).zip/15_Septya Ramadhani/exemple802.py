
my_tuple = ("hello")   # only parentheses is not enough
type(my_tuple)


my_tuple = ("hello",)  # need a comma at the end
type(my_tuple)

my_tuple = "hello",    # parentheses is optional
type(my_tuple)

model1= 'ChatGPT'
print(model1[6]) 
print(model1[-1]) 
# 1. Mendefinisikan variabel dan mengimpor modul
a = 1
b = "hello"
import math

# 2. Menampilkan semua variabel/modul yang terdaftar di ruang kerja saat ini
print(dir())
import os

os.listdir()
print(os.listdir)

# rename a directory
os.rename

os.listdir()
print(os.listdir)
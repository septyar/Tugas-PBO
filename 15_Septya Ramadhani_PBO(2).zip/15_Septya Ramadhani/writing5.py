import csv

row_list = [
    ["SN", "Name", "Quotes"],
    [1, "Buddha", "What we think we become"],
    [2, "Mark Twain", "Never regret anything that made you smile"],
    [3, "Oscar Wilde", "Be yourself everyone else is already taken"]
]


with open('quotes.csv', 'w', newline='') as file:
    writer = csv.writer(file, quoting=csv.QUOTE_NONNUMERIC,
                        delimiter=';', quotechar='*')
    writer.writerows(row_list)


print("--- ISI FILE QUOTES.CSV (DENGAN QUOTECHAR '*') ---")
with open('quotes.csv', 'r') as file:
    reader = csv.reader(file, delimiter=';', quotechar='*')
    for row in reader:
        print(row)
vowels = "aeiou"

# Convert a string to a list
vowels_list = list(vowels)
print(vowels_list)
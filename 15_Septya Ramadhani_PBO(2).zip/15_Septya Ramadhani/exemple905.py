model = 'ChatGPT'

# Access characters from index 0 up to (but not including) 4
print(model[0:4])   # Output: Chat
import csv

data = [
    ['SN', 'Name', 'Contribution'],
    ['1', 'Linus Torvalds', 'Linux Kernel'],
    ['2', 'Tim Berners-Lee', 'World Wide Web'],
    ['3', 'Guido van Rossum', 'Python Programming']
]

with open('innovators.csv', 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerows(data)

with open('innovators.csv', 'r') as file:
    reader = csv.reader(file)
    for row in reader:
        print(row)
n = 10

# Iterate from i = 1 to n
for i in range(1, n+1):
    print(i)
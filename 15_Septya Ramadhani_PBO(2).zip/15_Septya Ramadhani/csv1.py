import csv

with open('people.csv', 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(["Nama", "Umur", "Pekerjaan"])
    writer.writerow(["Budi", "25", "Programmer"])
    writer.writerow(["Siti", "30", "Desainer"])

with open('people.csv', 'r') as file:
    reader = csv.reader(file)
    for row in reader:
        print(row)
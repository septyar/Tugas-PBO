def future_function(angka1, angka2):
    hasil = angka1 + angka2
    return hasil

# Memanggil fungsi
total = future_function(10, 20)
print(f"Hasil penjumlahan: {total}")
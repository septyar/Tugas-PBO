my_tuple = ['p','e','r','m','i','t']

print(my_tuple[0])
print(my_tuple[5])

print(my_tuple[5])   # index must be in range

print(my_tuple[2]) # index must be an integer

n_tuple = ("mouse", [8, 4, 6], (1, 2, 3))

print(n_tuple[0][3]) # nested index
print(n_tuple[1][1])  # nested index
print(n_tuple[2][0]) # nested index

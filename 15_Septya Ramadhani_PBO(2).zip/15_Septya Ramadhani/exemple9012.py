example = """He said, "What's there?"""
print(example) 

example_2 = "He said, \"What's there?\""
print(example_2) 

cart = ["T-shirt", "Lamp", "Pen"]

result = "Lamp" in cart
print(result)   # True

result = "Book" in cart
print(result)   # False
model = 'ChatGPT'

model1 = 'W' + model[1:]
print(model1)
import os
import shutil

open("myfile.txt", "w").close() 
os.remove("myfile.txt")

os.mkdir("mydir") 
os.rmdir("mydir")

os.mkdir("mydir2")
open("mydir2/contoh.txt", "w").close()
shutil.rmtree("mydir2")
# Implement token calculation later 
def calculate_token():
    pass     